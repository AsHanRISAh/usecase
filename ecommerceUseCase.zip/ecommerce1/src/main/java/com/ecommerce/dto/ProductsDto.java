package com.ecommerce.dto;

public class ProductsDto {
	
	private long proudctId;
	private int quantity;
	/**
	 * @return the proudctId
	 */
	public long getProudctId() {
		return proudctId;
	}
	/**
	 * @param proudctId the proudctId to set
	 */
	public void setProudctId(long proudctId) {
		this.proudctId = proudctId;
	}
	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
